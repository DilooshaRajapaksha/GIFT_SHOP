import React from "react";
import "./AdminPage.css";

function AdminPage() {
  return (
    <div className="admin-wrapper">
      <h1>Admin Dashboard</h1>
      <p>This is a test page for admin access.</p>
    </div>
  );
}

export default AdminPage;